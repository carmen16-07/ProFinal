<?php
          include ('config.php');
session_start();

if(isset($_POST['comparprenda']))
{
    $nombre_comprador= $_POST['nombre_comprador'];
    $codigo_producto= $_POST['codigo_producto'];
    $talla_producto= $_POST['talla_producto'];
    $cantidad= $_POST['cantidad'];
    
    
    $query = $connection->prepare("INSERT INTO blusas(NOMBRE_COMPRADOR,CODIGO_PRODUCTO,TALLA_PRODUCTO,CANTIDAD)"
            ."VALUES(:nombre_comprador,:codigo_producto,:talla_producto,:cantidad)");
    $query->bindParam("nombre_comprador", $nombre_comprador,PDO::PARAM_STR);
    $query->bindParam("codigo_producto", $codigo_producto,PDO::PARAM_STR);
    $query->bindParam("talla_producto", $talla_producto,PDO::PARAM_STR);
    $query->bindParam("cantidad", $cantidad,PDO::PARAM_STR);
    $result=$query->execute();
    
    if($result){
        echo '<p class="sucess">Registrado </p>';
    }
 else {
        echo '<p class="error">No Registrado </p>';
    }
}
        ?>
    </body>
</html>

<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="estilolista.css">
    </head>
    <h2>Blusas</h2>
    <body>
        <form method="post" action="" name="comparprenda">
    <div class="form-element">
        <label>Nombre de comprador</label>
        <input type="text" name="nombre_comprador"  required/>
    </div>
    <div class="form-element">
        <label>Codigo de producto</label>
        <input type="text" name="codigo_producto" required/>
    </div>
    <div class="form-element">
        <label>Talla</label>
        <select type="text" class="form-element" name="talla_producto">
                <option>CH</option>
                <option>M</option>
                <option>G</option>
            </select>
    </div>
    <div class="form-element">
        <label>Cantidad</label>
        <input type="text" name="cantidad" required/>
    </div>
    <button type="submit" name="comparprenda" value="comparprenda">Comprar</button>
</form
       

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

    <title></title>
  </head>
  <body>
      
      <link rel="stylesheet"href="fotos.css">
      <link rel="stylesheet"href="estilomuestras.css">
      <link rel="stylesheet"href="titulos.css">
      <link rel="stylesheet"href="estilobusq.css">
    
      <section id="galeria" class="container">
          <div class="text-center pt-5">
              
              <h1>Bienvenida</h1>
              <input type="button" value="Pagina anterior" onclick="history.go(-1);">
          </div>
          <div class="row">

              <div class="col-lg-4">
                  <img src="imagen/Blusas/img1.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B100 Blusa: Blanca Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/img2.jpg"  alt="Galeria Imagen">
                  <h2>Codigo: B101 Blusa: Gris Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/img3.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B102 Blusa: Blanca olnanes Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/img5.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B103 Blusa: Negra puntos Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/b1.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B104 Blusa: verde c/flores Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/b2.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B105 Blusa: Blanca flores Azules Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/b4.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B107 Blusa: Azul tableada Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/b5.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B108 Blusa: Carmin puntos blancos Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/b6.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B109 Blusa: Guinda botones Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/b7.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B110 Blusa: Verde Soldado Talla: Ch, M, G</h2>
              </div>

              <div class="col-lg-4">
                  <img src="imagen/Blusas/b8.jpg" alt="Galeria Imagen">
                  <h2>Codigo: B111 Blusa: Lila Globo Talla: Ch, M, G</h2>
              </div>
          </div>
      </section>

    
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>

    <!-- Option 2: jQuery, Popper.js, and Bootstrap JS
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js" integrity="sha384-9/reFTGAW83EW2RDu2S0VKaIzap3H66lZH81PoYlFhbGU+6BZp6G7niu735Sk7lN" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.min.js" integrity="sha384-w1Q4orYjBQndcko6MimVbzY0tgp4pWB4lZ7lr30WKz0vr/aWKhXdBNmNb5D92v7s" crossorigin="anonymous"></script>
    -->
  </body>
</html>



        
