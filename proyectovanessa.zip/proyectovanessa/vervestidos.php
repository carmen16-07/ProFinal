<?php
include ('config.php');
session_start();

if(isset($_POST['mostrarusuarios'])){
    $buscar_usuarios= $_POST['buscar_usuarios'];
    $query=$connection->prepare("SELECT * FROM vestidos WHERE NOMBRE_COMPRADOR=:buscar_usuarios");
    $query->bindParam("buscar_usuarios",$buscar_usuarios, PDO::PARAM_STR);
    $query->execute();
     
    while ($row=$query->fetch(PDO::FETCH_ASSOC))
    {
       $nombre=$row['nombre_comprador'];
        $codigo=$row['codigo_producto'];
        $talla=$row['talla_producto'];
        $cantidad=$row['cantidad'];
       
        
       echo "<div class=\"usuario\">Nombre de comprador: $nombre </div>";
       echo "<div class=\"usuario\">Codigo de producto: $codigo </div>";
       echo "<div class=\"usuario\">Talla de producto: $talla </div>";
       echo "<div class=\"usuario\">Cantidad de producto: $cantidad </div>";
    }
}

?>
<html>
    <head>
    </head>
    <link rel="stylesheet"href="estilobusq.css">
    <link rel="stylesheet"href="consultas.css">
    <div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well well-sm">
                <form class="form-horizontal" method="post" name="mostrarusuarios">
                    <fieldset>
                        <legend class="text-center header">Escribir nombre de comprador</legend>

                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                            <div class="col-md-8">
                                <input id="buscar_usuarios" name="buscar_usuarios" type="text" placeholder="Usuario" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary btn-lg" name="mostrarusuarios" value="mostrarusuarios">Buscar</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
</html>

