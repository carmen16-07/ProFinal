<?php
include ('config.php');
session_start();

if(isset($_POST['eliminar']))
{
    $username=$_POST['username'];
    
        $query=$connection->prepare("DELETE FROM users WHERE USERNAME='$username'");
        
        $query->bindParam("username",$username, PDO::PARAM_STR);
       
         $result=$query->execute();
         
    if($result){
        echo '<p class="sucess">ELIMINADO</p>';
    }
    
 else {
        echo '<p class="error"> No registrado'
     . '</p>';   
    }
    
    }
?>


<form method="post" action="" name="eliminar">
    <h1>Registrese o inicie sesion</h1>
    <div class="form-element">
        <label>Usuario</label>
        <input type="username" name="username" required/>
    </div>
    
    <button type="submit" name="eliminar" value="eliminar">eliminar</button>
</form>



