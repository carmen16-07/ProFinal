
<html>
    <head>
        <h1>Elija que compra desea modificar</h1>
        
        <li><a href="modificarvestido.php">Vestidos</a>
    <li><a href="modificarblusa.php">Blusas</a></li>
    <li><a href="modificarpantalones.php">Pantalones</a></li>
    <li><a href="modificaraccesorios.php">Accesorio</a></li>
    </body>
</html>

