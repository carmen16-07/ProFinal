<link rel="stylesheet" href="EstiloLo.css">
<?php

session_start();
if(isset($_SESSION['user_id']))
{
    header('Location: Login.php');
    exit;
}
 else 
{
    
}
?>
<body>
    
    <h1>Bienvenido</h1>
    
    
</body>
<html></html>

