<?php
define('USER', 'root');
define ('PASSWORD', '');
define('HOST', 'Localhost');
define('DATABASE', 'usuarios');
try{
    $connection=new PDO ("mysql:host=".HOST."; dbname=".DATABASE, USER, PASSWORD); 
} catch (PDOException $e){
    exit("error: ".$e->getMessage());
}
?>

