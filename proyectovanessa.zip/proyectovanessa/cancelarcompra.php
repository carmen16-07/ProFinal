
<html>
    <head>
        <h1>Elija que compra desea cancelar</h1>
        
        <li><a href="Eliminarvestido.php">Vestidos</a>
    <li><a href="Eliminarblusas.php">Blusas</a></li>
    <li><a href="Eliminarpantalon.php">Pantalones</a></li>
    <li><a href="Eliminaraccesorio.php">Accesorio</a></li>
    </body>
</html>
