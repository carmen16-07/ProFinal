<html>
    <head>
        <meta charset="UTF-8">
        <title>Loketa</title>
        <link rel="stylesheet" href="Estilo.css">
        <link rel="stylesheet" href="titulos.css">
    </head>
    <body>
        <h1>BIENVENIDA</h1>
        <h2>En Loketa estamos para servirte</h2>
        <menu class="indice">
            <div class="col"></div>
            <ul class="main-menu indice">
                <li><a href="#">Inicio</a>
                <div class="desplegable menu">
                    <ul>
                        <li><a href="#">Datos</a></li>
                        <li><a href="index.php">Cerrar-Sesion</a></li>
                        <li><a href="visualizar.php">Productos comprados</a></li>
                    </ul>
   
                    <ul>
                        <li><a href="#">Editar</a></li>
                        <li><a href="modifciarusuarios.php">Modificar Usuario</a></li>
                        <li><a href="buscarusuario.php">Buscar usuario</a></li>
                        <li><a href="eliminarusuario.php">eliminar mi usuario</a></li>
                        <li><a href="cancelarcompra.php">cancelar compra</a></li>
                        <li><a href="modificarcompra.php">modificar compra</a></li>
                        
                    </ul>
                </div>
                </li>
                
                <li><a href="#">Productos</a>
                <div class="desplegable menu">
                    <ul>
                        <li><a href="#">Existencia</a></li>
                        <li><a href="TipoRopa.php">Ropa</a></li>
                        <li><a href="Accesorios.php">Accesorios</a></li>
                    </ul>
                </div>
                </li>
                
                <li><a href="#">Tienda</a>
                <div class="desplegable menu">
                    <ul>
                        <li><a href="#">Datos</a></li>
                        <li><a href="Ubicacion.php">Ubicacion</a></li>
                        <li><a href="#">Numero de Telefono</a></li>
                        <li><a href="#">Propietario</a></li>
                    </ul>
                </div>
                </li>
                
            </ul>
        </menu>
        
        
        <div class="slider">
            <ul>
                <li> <img src="imagen/img1.png" ></li>
                <li> <img src="imagen/img2.jpg" ></li>
                <li> <img src="imagen/img4.jpg" ></li>
                <li> <img src="imagen/img5.jpg" ></li>
            </ul>
        </div>
        <?php
        // put your code here
        ?>
    </body>
</html>
