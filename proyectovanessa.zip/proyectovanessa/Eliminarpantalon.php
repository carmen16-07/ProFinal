<?php
include ('config.php');
session_start();

if(isset($_POST['eliminarprenda']))
{
    $nombre_comprador= $_POST['nombre_comprador'];
    
    $query= $connection->prepare("DELETE FROM pantalones WHERE NOMBRE_COMPRADOR='$nombre_comprador'");
    $query->bindParam("nombre_comprador", $nombre_comprador,PDO::PARAM_STR);
    $result=$query->execute();
    
    if($result){
        echo '<p class="sucess">ELIMINADO </p>';
    }
 else {
        echo '<p class="error">No Eliminado </p>';
    }
}
?>

<form method="post" action="" name="eliminarprenda">
    <div class="form-element">
        <label>Nombre de comprador</label>
        <input type="text" name="nombre_comprador"  required/>
    </div>
    <button type="submit" name="eliminarprenda" value="eliminarprenda">Eliminar</button>
</form>

