
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link rel="stylesheet" href="Estilo.css">
    </head>
    <body>
        <h1>En Loketa Store contamos con diferentes tipos de vestidos. 
            Puedes elegir el que mas te guste, el que mas se amolde a ti
        </h1>
        <div class="slider">
            <ul>
                <li> <img src="imagen/img.jpg" ></li>
                <li> <img src="imagen/imgi.jpg" ></li>
                <li> <img src="imagen/imgp.jpg" ></li>
                <li> <img src="imagen/imgr.jpg" ></li>
                <li> <img src="imagen/imgt.jpg" ></li>
                <li> <img src="imagen/imgy.jpg" ></li>
            </ul>
        </div>
        <?php
         
        ?>
    </body>
</html>
