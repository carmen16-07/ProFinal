<?php
include('config.php');
session_start(); 
if(isset($_POST['Login']))
{
    $username = $_POST['username'];
    $password = $_POST['password'];
    $query=$connection->prepare("SELECT * FROM users WHERE USERNAME=:username");
    $query->bindParam("username", $username, PDO::PARAM_STR);
    $query->execute();
    $result=$query->fetch(PDO::FETCH_ASSOC);
    if(!$result)
    {
        echo '<p class = "error"> Datos Erroneos</p>';
    }
    else 
    {
    if(password_verify($password, $result['password']))
    {
        $_SESSION['user_id']=$result['id'];
        echo '<p class = "Succes"> Login correcto</p>';   
        if(!isset($_SESSION['user_id']))
        {
            header('Location: Login.php');
            exit;
        }
        else
        {
            header('Location: empezar.php');
            exit;
        }
    }  
    else 
    {
        echo '<p class = "error"> Datos Erroneos</p>';
    } 
    }
}
?>
<html>
    <head>
        <h1>BIENVENI@ ingrese sus datos o registrese gaturitamente</h1>
        <title>Login</title>
        <link rel="stylesheet" href="EstiloLo.css">
    </head>
    <body>
        <form method="post" action="" name="signin-form">
            <div class="form-element">
        <label>Usuario</label>
        <input type="text" name="username"  required/>
    </div>
    <div class="form-element">
        <label>Contrase#a</label>
        <input type="password" name="password" required/>
    </div>
    <button type="submit" name="Login" value="Login">Iniciar Sesion</button>
    <h1><a href="register.php">Registrarme</a></h1>
        </form>
    </body>
</html>

