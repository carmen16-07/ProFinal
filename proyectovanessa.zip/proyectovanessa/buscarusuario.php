<?php
include ('config.php');
session_start();

if(isset($_POST['mostrarusuarios'])){
    $buscar_usuarios= $_POST['buscar_usuarios'];
    $query=$connection->prepare("SELECT * FROM users WHERE USERNAME=:buscar_usuarios");
    $query->bindParam("buscar_usuarios",$buscar_usuarios, PDO::PARAM_STR);
    $query->execute();
     
    while ($row=$query->fetch(PDO::FETCH_ASSOC))
    {
       $usuario=$row['username'];
        $contraseña=$row['email'];
       echo "<div class=\"usuario\">Nombre de usuario: $usuario </div>";
       echo "<div class=\"usuario\">Email de usuario: $contraseña </div>";
    }
}

?>

<html>
    <head>
    </head>
    <link rel="stylesheet"href="estilobusq.css">
    <link rel="stylesheet"href="consultas.css">
    <div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="well well-sm">
                <form class="form-horizontal" method="post" name="mostrarusuarios">
                    <fieldset>
                        <legend class="text-center header">Escribir nombre de usuario</legend>

                        <div class="form-group">
                            <span class="col-md-1 col-md-offset-2 text-center"><i class="fa fa-user bigicon"></i></span>
                            <div class="col-md-8">
                                <input id="buscar_usuarios" name="buscar_usuarios" type="text" placeholder="Usuario" class="form-control">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-12 text-center">
                                <button type="submit" class="btn btn-primary btn-lg" name="mostrarusuarios" value="mostrarusuarios">Buscar</button>
                            </div>
                        </div>
                    </fieldset>
                </form>
            </div>
        </div>
    </div>
</div>
</html>
