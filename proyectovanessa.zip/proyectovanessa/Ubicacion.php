<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <div class="slider">
            <ul>
                <li> <img src="imagen/imgubi.jpg"alt="#" width="800" height="500" ></li>
            </ul>
        </div>
        <?php
         
        ?>
    </body>
</html>