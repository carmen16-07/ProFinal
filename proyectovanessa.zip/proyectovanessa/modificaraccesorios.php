<?php
include ('config.php');
session_start();

if(isset($_POST['register'])){
    $nombre_comprador=$_POST['nombre_comprador'];
    $codigo_producto=$_POST['codigo_producto'];
    $cantidad_producto=$_POST['cantidad_producto'];
   
    
   
        $query=$connection->prepare("UPDATE accesorios  set NOMBRE_COMPRADOR='$nombre_comprador',CODIGO_PRODUCTO='$codigo_producto',CANTIDAD_PRODUCTO='$cantidad_producto' WHERE NOMBRE_COMPRADOR='$nombre_comprador'");
        $query->bindParam("nombre_comprador",$nombre_comprador, PDO::PARAM_STR);
        $query->bindParam("codigo_producto",$codigo_producto, PDO::PARAM_STR);
        $query->bindParam("cantidad_producto",$cantidad_producto, PDO::PARAM_STR);
        
         $result=$query->execute();
         
    if($result){
        echo '<p class="sucess">Modificado</p>';
    }
    
 else {
        echo '<p class="error"> No registrado'
     . '</p>';   
    }
    
    }
            

?>

<form method="post" action="" name="signup-form">
    
    <div class="form-element">
        <label>Nombre</label>
        <input type="text" name="nombre_comprador" required/>
    </div>
    
    <div class="form-element">
        <label>codigo</label>
        <input type="text" name="codigo_producto" required/>
    </div>
    
    <div class="form-element">
        <label>cantidad</label>
        <input type="text" name="cantidad_producto" required/>
    </div>
   
    <button type="submit" name="register" value="register">modificar</button>
</form>



