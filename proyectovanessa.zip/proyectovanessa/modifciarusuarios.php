<?php
include ('config.php');
session_start();

if(isset($_POST['register'])){
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];
    $password_hash= password_hash($password, PASSWORD_BCRYPT);
    
   
        $query=$connection->prepare("UPDATE users  set USERNAME='$username',PASSWORD='$password_hash' ,EMAIL='$email' WHERE USERNAME='$username'");
        $query->bindParam("username",$username, PDO::PARAM_STR);
        $query->bindParam("password_hash",$password_hash, PDO::PARAM_STR);
        $query->bindParam("email",$email, PDO::PARAM_STR);
         $result=$query->execute();
         
    if($result){
        echo '<p class="sucess">Modificado</p>';
    }
    
 else {
        echo '<p class="error"> No registrado'
     . '</p>';   
    }
    
    }
            

?>

<form method="post" action="" name="signup-form">
    <h1>Registrese o inicie sesion</h1>
    <div class="form-element">
        <label>Usuario</label>
        <input type="username" name="username" required/>
    </div>
    
    <div class="form-element">
        <label>Email</label>
        <input type="email" name="email" required/>
    </div>
    
    <div class="form-element">
        <label>Contraseña</label>
        <input type="password" name="password" required/>
    </div>
    <button type="submit" name="register" value="register">modificar</button>
</form>

